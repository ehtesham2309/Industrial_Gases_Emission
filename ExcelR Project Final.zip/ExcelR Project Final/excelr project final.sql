
select * from ['Data 1$']
select * from ['Data 2$']

select fuel_type as fuel_name,sum(MMBtu_TOTAL) as gwht_tot from ['Data 1$'] group by FUEL_TYPE

select fuel_type as Fuel_name,round(sum(MMBtu_TOTAL),1) as MMBtu_tot from ['Data 1$']
 where fuel_type in ('ethane','Ethanol (100%)') group by FUEL_TYPE


select b.facility_name,round(sum(a.[process heating]),2) as process_heating from ['Data 2$'] a 
left join ['Data 1$'] b on a.primary_naics_code=b.primary_naics_code where b.FACILITY_NAME='3M COMPANY'
group by FACILITY_NAME


select convert(varchar,[unit name 2],105) as Unit_name,round(SUM(Gwht_total),1) as gwht_tot from ['Data 1$']
where [Unit name 2] like '1950%' or [Unit name 2] like '1981%' or [Unit name 2] like '1990%'
or [Unit name 2] like '1997%' or [Unit name 2] like '2022%'
group by [Unit name 2] order by [Unit name 2] desc


select b.Mecs_region,round(sum(a.[Direct uses-Total nonprocess]),1) as Total_non_process,
round(sum(a.[Direct uses-Total nonprocess])*100/(select sum(a.[Direct uses-Total nonprocess]) from ['Data 2$'] a 
left join ['Data 1$'] b
on a.primary_naics_code=b.primary_naics_code),1) as Percent_of_process_heating
from ['Data 2$'] a left join ['Data 1$'] b
on a.primary_naics_code=b.primary_naics_code where MECS_Region is not null
group by b.MECS_Region order by Percent_of_process_heating desc


select b.COUNTY,round(sum(a.[Conventional Boiler Use]),0) as Sum_,round(avg(a.[Conventional Boiler Use]),0) as avg_,
round(max(a.[Conventional Boiler Use]),0) as max_,round(min(a.[Conventional Boiler Use]),0) as min_ from ['Data 2$'] a 
left join ['Data 1$'] b on a.primary_naics_code=b.primary_naics_code
group by b.COUNTY order by COUNTY



